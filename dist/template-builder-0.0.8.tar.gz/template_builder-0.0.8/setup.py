# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': '.'}

packages = \
['src',
 'src.project_models',
 'src.project_models.py_models',
 'src.template_builder',
 'src.template_builder.cli',
 'src.template_builder.logic_files']

package_data = \
{'': ['*'], 'src': ['docs/*'], 'src.project_models': ['templates/*']}

install_requires = \
['Jinja2>=3.1.2,<4.0.0',
 'loguru>=0.6.0,<0.7.0',
 'pydantic>=1.10.2,<2.0.0',
 'rich>=12.6.0,<13.0.0',
 'tomlkit>=0.11.4,<0.12.0',
 'typer[all]>=0.6.1,<0.7.0']

entry_points = \
{'console_scripts': ['stencil = src.template_builder.main:main']}

setup_kwargs = {
    'name': 'template-builder',
    'version': '0.0.8',
    'description': '',
    'long_description': 'None',
    'author': 'Terry Dullaghan',
    'author_email': 't.ma.dullaghan@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
