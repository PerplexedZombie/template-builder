from src.template_builder.cli.cli import cli_app


def main():
    cli_app()
