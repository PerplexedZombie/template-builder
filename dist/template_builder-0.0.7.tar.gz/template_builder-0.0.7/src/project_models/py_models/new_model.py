from typing import List
from src.project_models.py_models.builder_config_base import BuilderConfigBase


class NewModel(BuilderConfigBase):
    where_col: str
    table_name: str
    where_condition: str
    columns_lst: List[str]
    