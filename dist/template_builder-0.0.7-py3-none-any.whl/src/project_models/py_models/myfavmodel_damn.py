from typing import List
from src.project_models.py_models.builder_config_base import BuilderConfigBase


class MyfavmodelDamn(BuilderConfigBase):
    my_var: str
    my_list: List[str]
    